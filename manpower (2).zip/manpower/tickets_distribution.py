import datetime
from functools import cmp_to_key

import openpyxl
import pandas
from collections import OrderedDict


class Event:
    populations = None

    def __init__(self, start: datetime, end: datetime, name, free_tickets):
        self.time_interval = (start, end)
        self.name = name
        self.free_tickets = free_tickets
        self.approved = set()
        self.requests = set()

    def __str__(self):
        return "name: {}, approved: {} free: {}, req:{}".format(self.name, len(self.approved), self.free_tickets,
                                                                self.get_order())

    def __le__(self, other):
        return self.get_order() <= other.get_order()

    def get_order(self):
        return {s: len([*filter(lambda t: s in t[2], self.requests)]) for s in self.free_tickets.keys()}

    @staticmethod
    def parse_allocations(file_path):
        events_dict = {}
        data_sheet = pandas.read_excel(file_path, sheet_name="alloc")
        Event.populations = list(data_sheet.columns[8:9])
        for i, row in data_sheet.iterrows():
            day, start, non, end = row["Event_ReqTime"].split(' ')
            events_dict[row["שם אירוע"]] = Event(datetime.datetime.strptime(day + start, "%d/%m/%Y%H:%M"),
                                                 datetime.datetime.strptime(day + end, "%d/%m/%Y%H:%M"),
                                                 row["שם אירוע"], {key: row[key] for key in Event.populations})
            # print(events_dict[row["שם אירוע"]])
        return events_dict


class Person:

    def __init__(self, mail, name):
        self.mail = mail
        self.name = name
        self.population = set()
        self.duties = set()
        self.acquired = set()
        self.denied = set()
        self.requests = set()

    def __str__(self):
        return "name: {}, population:{}, order: {}".format(self.name, self.population, self.get_order())

    def __lt__(self, other):
        return self.get_order() < other.get_order()

    def __le__(self, other):
        return self.get_order() <= other.get_order()

    def get_ticket(self, event_name):
        for req in self.requests:
            if req[1] == event_name:
                return req
        return None

    def get_order(self):
        if 'מתנדב' in self.population and len(self.population) == 1:
            if len(self.duties) == 0:
                return 10000, 1000
            return len(self.acquired) / len(self.duties), len(self.requests)
        return len(self.acquired), len(self.requests)

    def check_intersections_duties(self, events):
        days = {s[0].day for s in self.duties}
        # if is in the HA'KAMA - everything is valid.
        ## TODO: update each time
        if "סגל" in self.population or 'אורח' in self.population or 18 in days or 19 in days or len(self.duties) > 1:
            days = {20, 21, 22}

        for request_tuple in self.requests:
            request = events[request_tuple[1]]
            day = request.time_interval[0].day
            if day not in days:
                self.denied.add(request_tuple)
                request.requests.remove((request_tuple[0], self.mail, ",".join(self.population)))
                # print(request, self)
                continue

            for duty in self.duties:
                if max(request.time_interval[0], duty[0]) < min(request.time_interval[1], duty[1]):
                    self.denied.add(request_tuple)
                    request.requests.remove((request_tuple[0], self.mail, ",".join(self.population)))
                    break
        self.requests.difference_update(self.denied)

    def acquire(self, events, ticket, population):
        self.acquired.add(ticket)
        self.requests.remove(ticket)
        events[ticket[1]].approved.add((ticket[0], self.mail))
        events[ticket[1]].requests.remove((ticket[0], self.mail, ",".join(self.population)))
        events[ticket[1]].free_tickets[population] -= 1

        ticket_interval = events[ticket[1]].time_interval
        for request in self.requests:
            request_interval = events[request[1]].time_interval
            if request_interval[0] <= ticket_interval[0] < request_interval[1] or \
                    ticket_interval[0] <= request_interval[0] < ticket_interval[1]:
                self.denied.add(request)
                events[request[1]].requests.remove((request[0], self.mail, ",".join(self.population)))
            # if max(request_interval[0], ticket_interval[0]) < \
            #         min(request_interval[1], ticket_interval[1]):
            #     self.denied.add(request)
            #     events[request[1]].requests.remove((request[0], self.mail, ",".join(self.population)))

        self.requests.difference_update(self.denied)

    @staticmethod
    def parse_user_list(user_list_path):
        persons_dict = {}
        data_sheet = pandas.read_excel(user_list_path, sheet_name="users")
        for i, row in data_sheet.iterrows():
            if isinstance(row["מייל"], float):
                continue
            mail = row["מייל"].lower().rstrip()
            if mail not in persons_dict.keys():
                persons_dict[mail] = Person(mail, row["שם מלא"])
            if row["אוכלוסייה"] not in Event.populations:
                if row["אוכלוסייה"] == 'אורח':
                    row["אוכלוסייה"] = 'סגל'
                    pass
                else:
                    # print(row["אוכלוסייה"])
                    persons_dict[mail].population.add('מתנדב')

            # persons_dict[mail].population.add(row["אוכלוסייה"])

        # print("\n".join(str(a) for a in persons_dict.values()))
        return persons_dict

    @staticmethod
    def parse_duties(person_dict, duties_xl_path):
        excel = pandas.read_excel(duties_xl_path, sheet_name=None)
        for day in excel:
            base_day = datetime.datetime.strptime(day, "%d-%m-%Y")
            for col in excel[day].columns:
                start, end = col.split('-')
                start = datetime.datetime.strptime(start, "%H:%M")
                end = datetime.datetime.strptime(end, "%H:%M")
                days = 0 if start < end else 1
                start = datetime.timedelta(hours=start.hour, minutes=start.minute)
                end = datetime.timedelta(hours=end.hour, minutes=end.minute, days=days)

                time_interval = (base_day + start, base_day + end)
                for name in excel[day][col]:
                    if isinstance(name, float):
                        continue
                    lst = [a for a in persons_dict.values() if a.name == name]
                    if len(lst) == 0:
                        lst = [a for a in persons_dict.values() if a.name == name[1:]]
                    if len(lst) != 1:
                        print("Got duties, but not registered :", name, time_interval, lst)
                        continue
                        # raise KeyError
                    person = lst[0]
                    person.duties.add(time_interval)
                    # print(name, type(name))
        # input("are there any errors? fix the data!")


def parse_requests(persons, events, file_path):
    data_sheet = pandas.read_excel(file_path, sheet_name="Request_report")
    for i, row in data_sheet.iterrows():
        if row["אושר"] == 1:
            continue
        if row["תפקידים"] != "מתנדב":
            continue
        mail = row["Mail"].strip()
        if mail not in persons or row["אירוע"] not in events:
            print("No person or event: ", row)
            continue
        events[row["אירוע"]].requests.add((row["מספר כרטיס"], mail, ",".join(persons[mail].population)))
        persons[mail].requests.add((row["מספר כרטיס"], row["אירוע"]))

    input("are there any errors? fix the data!")


def distribute_population(all_events, pop, all_persons):
    def comp(x, y):
        return all_events[y].get_order()[pop] - all_events[x].get_order()[pop]

    def per_cmp(x, y):
        return

    events = [
        *filter(lambda x: all_events[x].get_order()[pop] != 0 and all_events[x].free_tickets[pop] != 0,
                all_events.keys())]
    events = sorted(events, key=cmp_to_key(comp))
    persons_pop = [*filter(lambda x: pop in all_persons[x].population, all_persons.keys())]

    while events:
        event = events[0]
        persons = [*filter(lambda x: x in [y[1] for y in all_events[event].requests], persons_pop)]
        persons = [*filter(lambda x: x.mail in persons, all_persons.values())]
        persons.sort()

        # all_persons[persons[0]].acquire(all_events, all_persons[persons[0]].get_ticket(event), pop)
        persons[0].acquire(all_events, persons[0].get_ticket(event), pop)

        events = [*filter(lambda x: all_events[x].get_order()[pop] != 0 and all_events[x].free_tickets[pop] != 0,
                          events)]
        events = sorted(events, key=cmp_to_key(comp))


def save_back(approved_list, requests_path):
    book = openpyxl.load_workbook(requests_path)

    count = 0
    for row in book.worksheets[0].iter_rows():
        ticket = row[1].value
        # print("ticket", ticket, ticket in approved_list)
        if ticket in approved_list:
            row[9].value = 1
            count += 1
    print("Check amount of approved ", len(approved_list), count)
    book.save(requests_path)
    # data_sheet.to_excel(requests_path, sheet_name="approves_report")


if __name__ == '__main__':
    events_dict = Event.parse_allocations("examples/users and tags3.xlsx")
    persons_dict = Person.parse_user_list("examples/users and tags3.xlsx")
    Person.parse_duties(persons_dict, "examples/duties2024.xlsx")
    parse_requests(persons_dict, events_dict, "examples/XLS_Request_report20230401_171720.xlsx")

    # remove people that didn't request tickets.
    lp = list(persons_dict.values())
    for p in lp:
        if len(p.requests) == 0:
            persons_dict.pop(p.mail)

    # # now remove duties intersections
    for user in persons_dict.values():
        user.check_intersections_duties(events_dict)

    # start distributing the tickets, per population.
    for pop in Event.populations:
        distribute_population(events_dict, pop, persons_dict)

    # TODO: uncomment if we re-distribute
    # # define new population - all, and set it's allocation to the remaining from every population
    # for event in events_dict.values():
    #     event.free_tickets['all'] = sum(event.free_tickets.values())
    # for person in persons_dict.values():
    #     person.population.add('all')
    #
    # distribute_population(events_dict, 'all', persons_dict)

    # check per person which tickets are approved
    approved_tickets = set()
    for per in persons_dict.values():
        for p in per.acquired:
            approved_tickets.add(p[0])

    save_back(approved_tickets, 'examples/XLS_Request_report20230401_171720.xlsx')
    # save_back(approved_tickets, 'examples/olamot2023_req.xlsx')

    # statictics!
    dist = {}
    for person in persons_dict.values():
        l = len(person.acquired)
        if l not in dist:
            dist[l] = []
        dist[l].append(person)
    for l in dist:
        print(l, len(dist[l]))
    print('\n'.join(str([p.name, p.duties, p.requests]) for p in dist[0]))
