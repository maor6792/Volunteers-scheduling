import unittest
from main import Job
from datetimerange import DateTimeRange


class TestJobIntersections(unittest.TestCase):
    @staticmethod
    def create_time_only_job(time_range):
        shift = DateTimeRange(*time_range.split('-'))
        job = Job(
            shift_id=0,
            job_id=0,
            key="",
            name="",
            num_volunteers_required=0,
            shift_start=shift.start_datetime,
            shift_end=shift.end_datetime,
        )
        return job

    def test_no_intersect(self):
        job1 = TestJobIntersections.create_time_only_job("21.4.2019,9:30-21.4.2019,14:30")
        job2 = TestJobIntersections.create_time_only_job("22.4.2019,13:30-22.4.2019,18:30")
        self.assertFalse(job1.intersects(job2))
        self.assertFalse(job2.intersects(job1))

    def test_intersection(self):
        job1 = TestJobIntersections.create_time_only_job("21.4.2019,9:30-21.4.2019,14:30")
        job2 = TestJobIntersections.create_time_only_job("21.4.2019,13:30-21.4.2019,18:30")
        self.assertTrue(job1.intersects(job2))
        self.assertTrue(job2.intersects(job1))


if __name__ == '__main__':
    unittest.main()
