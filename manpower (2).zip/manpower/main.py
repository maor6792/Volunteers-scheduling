import datetime

from mongoengine import *
from io import StringIO
import pandas as pd
from datetimerange import DateTimeRange
from datetime import timedelta
import codecs
import warnings

# The warning I'm ignoring here happens when no excel is installed on the relevant computer.
# According to Stackoverflow it can be safely ignored.
warnings.filterwarnings('ignore', category=UserWarning, module='openpyxl')

volunteer_responses_path = r".\examples\resp.xlsx"
# volunteer_responses_path = r".\examples\Olamot22_custodies.xlsx"


# connect('mongodb+srv://test_uname:test_password@cluster0.xln6c.mongodb.net/test?retryWrites=true&w=majority')


'''class Job(Document):
    shift_id = IntField(required=True)
    job_id = IntField(required=True)
    key = StringField(required=True, primary_key=True)
    name = IntField(required=True)
    shift_start = DateTimeField(required=True, datetime_format="'datetime'")
    shift_end = DateTimeField(required=True, datetime_format="'datetime'")
    num_volunteers_required = IntField(required=True)
    volunteer_keys = ListField(required=True, default=[])

    possible_volunteers = None  # This needs to be of set() type, can't be initiated here (becomes a global if it is).

    @staticmethod
    def job_key(shift_id, job_id):
        return str((shift_id, job_id))

    def get_num_volunteers_needed(self):
        return self.num_volunteers_required - len(self.volunteer_keys)

    def get_order(self):
        return len(self.possible_volunteers) - self.get_num_volunteers_needed()

    def intersects(self, other):
        """
        return True if they are within ten hours of each other.
        """
        assert isinstance(other, Job)
        time_delta = timedelta(hours=10)
        encompassing_datetimerange = DateTimeRange(self.shift_start - time_delta,
                                                   self.shift_end + time_delta)
        # This is the best way I found to convert DateTimeField to datetime
        no_time_delta = timedelta(hours=0)
        other_datetimerange = DateTimeRange(other.shift_start - no_time_delta,
                                            other.shift_end + no_time_delta)
        return encompassing_datetimerange.is_intersection(other_datetimerange)

    def get_day(self):
        return self.shift_start.date()

    def get_start_time(self):
        return self.shift_start.time()

    def get_end_time(self):
        return self.shift_end.time()

    def __str__(self):
        return f"name: {self.name}\nday: {self.get_day()}\nstart: {self.get_start_time()}\nend: {self.get_end_time()}"

    def get_full_job_details(self, volunteer_dict):
        result = f"job:\n{str(self)}\n{len(self.volunteer_keys)}/{self.num_volunteers_required} volunteers."
        volunteer_count = 1
        for volunteer_key in self.volunteer_keys:
            result += f"\n\nvolunteer {volunteer_count}:\n{str(volunteer_dict[volunteer_key])}"
            volunteer_count += 1
        return result
'''


class Job:
    def __init__(self, custody_type, time_slot, required_volunteers):
        self.type = custody_type
        self.time = time_slot
        self.req = required_volunteers
        self.total_req = required_volunteers
        self.registers = []
        self.options = []

    def get_order(self):
        if self.req == 0:
            return 0
        return self.req / (len(self.options) + 1)


class Volunteer(Document):
    email = StringField(required=True)
    name = StringField(required=True)
    key = StringField(required=True, primary_key=True)
    jobs = ListField(required=True, default=[])

    requested_jobs = None  # This needs to be of set() type, can't be initiated here (becomes a global if it is).

    @staticmethod
    def volunteer_key(email):
        return email

    @staticmethod
    def convert_requests_to_possible_jobs(job_dict, requested_shift_ids, requested_job_ids):
        return {(j, s) for s in requested_shift_ids for j in requested_job_ids if (j, s) in job_dict.keys()}

    def get_order(self):
        return len(self.jobs), len(self.requested_jobs), self.email

    def __str__(self):
        return f"name: {self.name}\nemail: {self.email}"

    def get_full_volunteer_details(self, job_dict):
        result = f"volunteer:\n{str(self)}\n{len(self.jobs)} jobs."
        job_count = 1
        for job_key in self.jobs:
            result += f"\n\njob {job_count}:\n{str(job_dict[job_key])}"
            job_count += 1
        return result


def parse_volunteer_responses(job_dict, job_translator, custody_translator):
    # The preprocessing done here is rather bad, but it's all you can do with the current raw's.
    # In its current form, it'll need to be touched up every year.
    xl = pd.read_excel(volunteer_responses_path, sheet_name=None)
    # key = list(xl.keys())[3]  # manual preprocessing....
    df = xl["responses"]

    def get_options(options, base_dict):
        if isinstance(options, float):
            options = str(options)
        result = set()
        for string in base_dict.keys():
            if options.find(string) != -1:
                result.add(base_dict[string])
        #     options.replace(string, base_dict[string])
        # for option in options.split(','):
        #     option.strip()
        #     if option in {"", " ", "nan"}:
        #         continue
        #     try:
        #         result.add(int(float(option)))
        #     except Exception as e:
        #         print(e)
        #         print(f"***{option}*** type: {type(option)}")  # *** needed in case of a string of spaces.
        return result

    volunteers = {}
    for i in range(df.shape[0]):
        row = df.iloc[i]
        email = row["mail"]
        volunteer = Volunteer(
            email=email,
            name=row["first"] + " " + row["last"],
            key=Volunteer.volunteer_key(email)
        )
        volunteer.requested_jobs = Volunteer.convert_requests_to_possible_jobs(job_dict,
                                                                               get_options(row["custodies"],
                                                                                           custody_translator),
                                                                               get_options(row["jobs"], job_translator))
        volunteers[volunteer.key] = volunteer
        # for sift in volunteer.requested_jobs:
        #     job_dict[sift].options.append(volunteer.key)

    return volunteers


def parse_shift_times():
    # The preprocessing done here is rather bad, but it's all you can do with the current raw's.
    # In its current form, it'll need to be touched up every year.
    xl = pd.read_excel(volunteer_responses_path, sheet_name=None)
    # key = list(xl.keys())[2]  # usable info
    meta_data = xl["metadata"]
    jobs_enc = {form_string: num for form_string, num in zip(meta_data["job"], meta_data["num"])
                if isinstance(form_string, str)}
    costudies_enc = {form_string: num for form_string, num in zip(meta_data["custody"], meta_data["num"])}
    costudy_intersections = {num: [int(x) for x in str(inter).split(',')] for num, inter in
                             zip(meta_data["num"], meta_data["intersections"])}

    print(len(jobs_enc), jobs_enc)
    df = xl["custodies"]
    job_names = list(df.keys())
    # jobs = {}
    print(jobs_enc.values())
    jobs = {(job, cstd): Job(job, cstd,
                             df.iloc[cstd, 1 + job])
            for cstd in costudies_enc.values() for job in jobs_enc.values()}
    for k in jobs.keys():
        if jobs[k].req == 0:
            pass
    # jobs = {k: jobs[k] for k in jobs.keys() if jobs[k].total_req != 0}

    # jobs = {j.key: j for j in jobs_arr}
    # for i in range(2, df.shape[0]):
    #     # This is a bit silly, but it's much better than any alternative I found.
    #     if df.iloc[i, 0] in {"", " ", "nan"} or isinstance(df.iloc[i, 0], float):
    #         continue
    #     shift = DateTimeRange(*df.iloc[i, 0].split('-'))
    #     shift_id = int(df.iloc[i, 2])
    #     for j in range(3, df.shape[1]):
    #         volunteers_required = df.iloc[i, j]
    #         if volunteers_required != 0:
    #             job_id = int(df.iloc[1, j])
    #             job = Job(
    #                 shift_id=shift_id,
    #                 job_id=job_id,
    #                 key=Job.job_key(shift_id, job_id),
    #                 name=job_names[j],
    #                 shift_start=shift.start_datetime,
    #                 shift_end=shift.end_datetime,
    #                 num_volunteers_required=int(volunteers_required)
    #             )
    #             job.possible_volunteers = set()
    #             jobs[job.key] = job

    return jobs, jobs_enc, costudies_enc, costudy_intersections


def pairing_algorithm(job_dict, volunteer_dict, intersections):
    """
    We order the volunteers according to the number of jobs they have,
    then according to the number of requested jobs,
    and then lexicographically on their email. All this from low to high.
    We order the jobs according to how difficult it'll be to find enough volunteers for those jobs,
    e.g. number_of_times_requested - volunteers_needed from low to high.
    We iterate over the jobs, and for each job find the first available volunteer.
    We remove said volunteer from the list, update his jobs, and remove all requested jobs within a 10-hour timeframe**
    We then repeat this process until all jobs have been filled.
    This algorithm puts a first priority on filling every job, while taking the details in the document into account.
    ** this means there could be better solutions that aren't found. I don't think it'll matter much.
    """

    while True:
        tobreak = True
        for vol in volunteer_dict.values():
            if vol.requested_jobs:
                tobreak = False
                break
        if tobreak:
            break

        for j in job_dict.values():
            j.options = []

        # remove non-existent jobs from volunteer.requested_jobs
        # populate job.possible_volunteers
        for volunteer in volunteer_dict.values():
            jobs_to_remove = set()
            for job_key in volunteer.requested_jobs:
                if (job_key in job_dict.keys()) and (job_dict[job_key].req > 0):
                    # if job_dict[job_key].possible_volunteers is None:
                    #     job_dict[job_key].possible_volunteers = set()
                    job_dict[job_key].options.append(volunteer.key)
                else:
                    jobs_to_remove.add(job_key)
            volunteer.requested_jobs -= jobs_to_remove

        # start of algorithm
        # annoying duplicate, what is the best way to remove?
        jobs = [job for job in job_dict.values() if job.req > 0 and
                len(job.options) > 0]
        if not jobs:
            break
        jobs.sort(key=lambda job: job.get_order(), reverse=True)
        job = jobs[0]
        volunteers = [volunteer_dict[key] for key in job.options]
        volunteers.sort(key=lambda v: v.get_order())
        # print([v.get_order() for v in volunteers])
        job.registers.append(volunteers[0].key)
        job.req -= 1
        volunteers[0].jobs.append((job.type, job.time))
        volunteers[0].requested_jobs = set(
            a for a in volunteers[0].requested_jobs if a[1] not in intersections[job.time])
        pass

    #
    # while len(jobs) > 0:
    #     jobs.sort(key=lambda j: j.get_order())
    #     for job in jobs:
    #         # alternative method - sort all volunteers (not per job) and go over them for each job.
    #         # you end up sorting less times, but going over more elements. IDK if this matters.
    #         if not job.options: continue
    #         volunteer = volunteer_dict[sorted(job.options, key=lambda v: volunteer_dict[v].get_order())[0]]
    #         job.options.append(volunteer.key)
    #         volunteer.jobs.append((job.type, job.time))
    #
    #         removed_jobs = {j for j in volunteer.requested_jobs if j in intersections[volunteer]}
    #         for j in removed_jobs:
    #             job_dict[j].options.remove(volunteer.key)
    #         volunteer.requested_jobs -= removed_jobs
    #
    #     jobs = [job for job in job_dict.values() if job.get_num_volunteers_needed() > 0 and
    #             len(job.options) > 0]


def print_statistics(job_dict, volunteer_dict, verb=False):
    def get_open_positions(j_dict):
        result = 0
        for j in j_dict.values():
            result += j.req
            if j.req != 0:
                pass
        return result

    result = {}
    for v in volunteer_dict.values():
        c = len(v.jobs)
        if c == 0 and verb:
            print("0: ", v)
        elif c == 5:
            print("5: ,", v, v.jobs)
        if c not in result:
            result[c] = 0
        result[c] += 1

    tmp = result
    for i in sorted(tmp.keys()):
        print(f"volunteers with {i} shifts: {tmp[i]}")

    open_positions = get_open_positions(job_dict)
    print(f"\nshifts filled: {sum(i * j for i, j in tmp.items())}\nopen shifts left: {open_positions}")


def get_shift_tables_times(job_dict, volunteer_dict, by_email=False):
    # This probably can and should be created in a dataframe directly, but this is simpler for me.
    used_values = {key: volunteer.email for key, volunteer in volunteer_dict.items()} if by_email else \
        {key: volunteer.name for key, volunteer in volunteer_dict.items()}

    jobs_by_dates = {}
    for key, job in job_dict.items():
        job_date = job.shift_start.date()
        if job_date not in jobs_by_dates:
            jobs_by_dates[job_date] = {}

        job_span = f"{job.shift_start.time()} - {job.shift_end.time()}"
        if job_span not in jobs_by_dates[job_date]:
            jobs_by_dates[job_date][job_span] = {}

        jobs_by_dates[job_date][job_span][key] = job

    csv_dict = {}
    for job_date, job_span_dict in jobs_by_dates.items():
        csv = ""
        for span, jobs in job_span_dict.items():
            csv += ","  # add an empty cell before the titles, because of the shift times in the next row
            max_volunteer_count = 0  # needed for padding later.
            for job in jobs.values():
                csv += f"{job.name},"
                if len(job.volunteer_keys) > max_volunteer_count:
                    max_volunteer_count = len(job.volunteer_keys)
            csv = csv[:-1]  # remove trailing ","
            for i in range(max_volunteer_count):
                csv += "\n," if i != 0 else f"\n{span},"
                for job in jobs.values():
                    csv += f"{used_values[job.volunteer_keys[i]]}," if i < len(job.volunteer_keys) else ","
                csv = csv[:-1]  # remove trailing ","
            csv += "\n\n"  # add a single line between two shifts
        csv_dict[job_date] = csv[:-2]  # remove trailing "\n\n"
    return csv_dict


def get_shift_tables_slots(job_dict, volunteer_dict, job_tran, cust_tran, by_email=False):
    # This probably can and should be created in a dataframe directly, but this is simpler for me.
    used_values = {key: volunteer.email for key, volunteer in volunteer_dict.items()} if by_email else \
        {key: volunteer.name for key, volunteer in volunteer_dict.items()}

    # csv_dict = {}
    csv = ""
    for job in job_dict.values():
        if job.total_req == 0: continue
        csv += job_tran[job.type] + "," + str(job.time) + "," + cust_tran[job.time] + "," + str(len(job.registers)) + "/" + \
               str(job.total_req) + "," + ",".join([volunteer_dict[key].name for key in job.registers]) + '\n'
    return {"results":csv}



    # for job_detail, job in job_dict.items():
    #         # csv += ","  # add an empty cell before the titles, because of the shift times in the next row
    #         max_volunteer_count = 0  # needed for padding later.
    #         for job in jobs.values():
    #             csv += f"{job.name},"
    #             if len(job.volunteer_keys) > max_volunteer_count:
    #                 max_volunteer_count = len(job.volunteer_keys)
    #         csv = csv[:-1]  # remove trailing ","
    #         for i in range(max_volunteer_count):
    #             csv += "\n," if i != 0 else f"\n{span},"
    #             for job in jobs.values():
    #                 csv += f"{used_values[job.volunteer_keys[i]]}," if i < len(job.volunteer_keys) else ","
    #             csv = csv[:-1]  # remove trailing ","
    #         csv += "\n\n"  # add a single line between two shifts
    #     csv_dict[job_date] = csv[:-2]  # remove trailing "\n\n"
    # return csv_dict


def save_shift_tables(csv_dict):
    xl = {date: pd.DataFrame([x.split(',') for x in csv.split("\n")]) for date, csv in csv_dict.items()}
    writer = pd.ExcelWriter(r'examples/result.xlsx')
    for date, df in xl.items():
        df.to_excel(writer, sheet_name=str(date))
    writer.save()


def main():
    job_dict, job_translator, custody_translator, intersections = parse_shift_times()
    volunteer_dict = parse_volunteer_responses(job_dict, job_translator, custody_translator)

    print_statistics(job_dict, volunteer_dict)

    ######################################
    # for i in custody_translator.values():
    #     s = "" + str(i) + ": "
    #     for j in job_translator.values():
    #         s += str(job_dict[(j, i)].req) + " "
    #     print(s)
    ######################################

    pairing_algorithm(job_dict, volunteer_dict, intersections)
    print_statistics(job_dict, volunteer_dict, True)
    # for
    csv_dict = get_shift_tables_slots(job_dict, volunteer_dict, {key:name.replace(",", " ") for name, key in job_translator.items()},
                                      {key:name.replace(",", " ") for name, key in custody_translator.items()})
    save_shift_tables(csv_dict)


if __name__ == "__main__":
    main()
